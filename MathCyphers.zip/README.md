# README #

### Purpose ###
A short sample demonstrating User Authorization using Orchestrate with Node JS.

### Set Up ###
Create a config.js file with the format:

```
#!javascript

module.exports = {
    "db":"OrchestrateKey"
}
```


Run npm install from the directory that contains the package.json file for this project 

Be sure all node module are located in the node_modules folder and up to date.

### Contact ###
Rodn725@gmail.com